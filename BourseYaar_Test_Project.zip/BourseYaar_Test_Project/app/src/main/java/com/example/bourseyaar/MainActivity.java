package com.example.bourseyaar;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView content;
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this); title.setText("بورس‌یار"); title.setTextSize(28); title.setGravity(Gravity.CENTER); title.setPadding(0,20,0,20); root.addView(title);
        content = new TextView(this); content.setText("نسخه آزمایشی بورس‌یار\n\nبرای شروع، یکی از بخش‌های زیر را انتخاب کنید."); content.setTextSize(18); content.setGravity(Gravity.CENTER); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,0,1); root.addView(content,cp);
        String[] tabs={"اطلاعات بورس","بنیادی","تکنیکال","پیشنهاد خرید","سهام من"};
        for(String s:tabs){ Button bt=new Button(this); bt.setText(s); bt.setTextSize(16); bt.setOnClickListener(v->content.setText("بخش «"+((Button)v).getText()+"»\n\nاین نسخه آزمایشی است. اتصال به TSETMC و کدال در مرحله بعد اضافه می‌شود.")); root.addView(bt,new LinearLayout.LayoutParams(-1,Wrap())); }
        setContentView(root);
    }
    int Wrap(){ return (int)(52*getResources().getDisplayMetrics().density); }
}
