package com.bourseyaar.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(32, 48, 32, 32);

        TextView title = new TextView(this);
        title.setText("بورس‌یار");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView body = new TextView(this);
        body.setText("\nنسخه اولیه بورس‌یار\n\n• اطلاعات کلی بازار\n• پول هوشمند\n• ورود و خروج پول\n• تحلیل بنیادی\n• تحلیل تکنیکال\n• بررسی نمادها\n• پیشنهادهای معاملاتی");
        body.setTextSize(20);
        body.setGravity(Gravity.RIGHT);
        root.addView(body, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
